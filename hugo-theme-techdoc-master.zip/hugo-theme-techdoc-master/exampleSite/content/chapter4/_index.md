---
title: "Chapter 4 (unlimited levels)"
date: 2017-10-17T15:26:15Z
draft: false
weight: 50
---

{{% panel status="primary" title="Note" icon="far fa-lightbulb" %}}
The document hierarchy is unlimite.
It also means that the menu levels is unlimited levels.

The menu levels has up to 5 levels of indentation. After that there is no indentation.
{{% /panel %}}


Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
